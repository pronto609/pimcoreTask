<?php


	namespace MehrItBufferTest;


	class TestCase extends \PHPUnit\Framework\TestCase
	{

	}