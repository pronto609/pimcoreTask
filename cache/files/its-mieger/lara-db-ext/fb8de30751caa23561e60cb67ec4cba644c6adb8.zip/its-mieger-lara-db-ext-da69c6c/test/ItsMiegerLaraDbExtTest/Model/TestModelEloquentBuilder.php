<?php
	/**
	 * Created by PhpStorm.
	 * User: chris
	 * Date: 29.11.18
	 * Time: 15:16
	 */

	namespace ItsMiegerLaraDbExtTest\Model;


	class TestModelEloquentBuilder extends BaseTestModel
	{
		protected $table = 'test_table';
	}