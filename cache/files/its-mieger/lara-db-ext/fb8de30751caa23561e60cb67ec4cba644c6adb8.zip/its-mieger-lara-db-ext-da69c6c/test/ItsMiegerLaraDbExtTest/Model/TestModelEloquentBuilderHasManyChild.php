<?php
	/**
	 * Created by PhpStorm.
	 * User: chris
	 * Date: 06.12.18
	 * Time: 19:29
	 */

	namespace ItsMiegerLaraDbExtTest\Model;


	class TestModelEloquentBuilderHasManyChild extends BaseTestModel
	{
		protected $table = 'test_eloquent_has_many_child_table';
	}