<?php


	namespace ItsMiegerLaraDbExtTest\Model;


	class TestBulkImport extends BaseTestModel
	{

		protected $table = 'bulk_import_tests';

	}