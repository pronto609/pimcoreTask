<?php
	/**
	 * Created by PhpStorm.
	 * User: chris
	 * Date: 05.12.18
	 * Time: 14:02
	 */

	namespace ItsMiegerLaraDbExtTest\Model;


	class TestModelQueryBuilder extends BaseTestModel
	{
		protected $table = 'test_query_table';
	}