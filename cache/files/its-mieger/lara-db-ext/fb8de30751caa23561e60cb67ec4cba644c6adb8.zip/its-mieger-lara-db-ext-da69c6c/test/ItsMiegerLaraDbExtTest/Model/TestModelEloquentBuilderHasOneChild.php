<?php
	/**
	 * Created by PhpStorm.
	 * User: chris
	 * Date: 06.12.18
	 * Time: 19:29
	 */

	namespace ItsMiegerLaraDbExtTest\Model;


	class TestModelEloquentBuilderHasOneChild extends BaseTestModel
	{
		protected $table = 'test_eloquent_has_one_child_table';
	}