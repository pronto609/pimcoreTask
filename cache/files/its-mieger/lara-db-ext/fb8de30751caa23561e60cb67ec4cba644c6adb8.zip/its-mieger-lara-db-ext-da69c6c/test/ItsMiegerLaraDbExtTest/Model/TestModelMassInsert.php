<?php
	/**
	 * Created by PhpStorm.
	 * User: chris
	 * Date: 12.12.18
	 * Time: 11:18
	 */

	namespace ItsMiegerLaraDbExtTest\Model;


	class TestModelMassInsert extends BaseTestModel
	{

		protected $table = 'mass_insert_tests';

	}