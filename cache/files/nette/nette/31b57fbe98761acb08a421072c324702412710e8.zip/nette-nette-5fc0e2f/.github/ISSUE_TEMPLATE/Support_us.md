---
name: "❤️ Support us"
about: "If you would like to support our efforts in maintaining this project 🙌"

---

--------------^ Click "Preview" for a nicer view!

> https://nette.org/donate

Help support Nette!

We develop Nette Framework for more than 14 years. In order to make your life more comfortable. Nette cares about the safety of your sites. Nette saves you time. And gives job opportunities.

Nette earns you money. And is absolutely free.

To ensure future development and improving the documentation, we need your donation.

Whether you are chief of IT company which benefits from Nette, or developer who goes for advice on our forum, if you like Nette, [please make a donation now](https://nette.org/donate).

Thank you!
