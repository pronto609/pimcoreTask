<?php

declare(strict_types=1);

namespace PHPSTORM_META;

override(\Nette\DI\Container::getByType(0), map(['' => '@']));
override(\Nette\DI\ContainerBuilder::addDefinition(1), type(1));
